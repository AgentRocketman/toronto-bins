<?php
require_once __DIR__ . '/config.php';
$config = require __DIR__ . '/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function error($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

// Auth
$authHeader = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
if ($authHeader !== $config['api_auth_token']) {
    error('Unauthorized', 401);
}

if ($config['telegram_bot_token'] === '__SET_ME__') {
    error('Telegram bot token not configured', 500);
}

if (!isset($_FILES['audio']) || $_FILES['audio']['error'] !== UPLOAD_ERR_OK) {
    error('Audio file required');
}

$allowedTypes = ['audio/wav', 'audio/webm', 'audio/mp4', 'audio/mpeg', 'audio/ogg', 'audio/aac'];
$mime = $_FILES['audio']['type'];
if (!in_array($mime, $allowedTypes, true)) {
    error('Unsupported audio type: ' . $mime);
}

$uploadDir = rtrim($config['upload_dir'], '/');
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Sanitize filename and move upload
$ext = pathinfo($_FILES['audio']['name'], PATHINFO_EXTENSION) ?: 'bin';
$requestId = bin2hex(random_bytes(8));
$filename = $requestId . '_' . time() . '.' . $ext;
$filepath = $uploadDir . '/' . $filename;

if (!move_uploaded_file($_FILES['audio']['tmp_name'], $filepath)) {
    error('Failed to save audio', 500);
}

// Send audio to Telegram
$apiBase = rtrim($config['telegram_api_base'], '/') . '/' . $config['telegram_bot_token'];
$url = $apiBase . '/sendAudio';

$postFields = [
    'chat_id' => $config['allowed_chat_id'],
    'audio' => new CURLFile($filepath, $mime, $filename),
    'caption' => '🎙️ Voice message from CurbIn Assistant',
    'title' => 'Voice message',
    'performer' => 'CurbIn Assistant',
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
$response = curl_exec($ch);
$err = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($err) {
    @unlink($filepath);
    error('Telegram request failed: ' . $err, 502);
}

$data = json_decode($response, true);
if (!$data || !($data['ok'] ?? false) || !isset($data['result']['message_id'])) {
    @unlink($filepath);
    error('Telegram send failed: ' . ($data['description'] ?? 'unknown'), 502);
}

$messageId = $data['result']['message_id'];

// Store mapping request_id -> telegram message_id
$storePath = $config['request_store'];
$store = [];
if (file_exists($storePath)) {
    $store = json_decode(file_get_contents($storePath), true) ?: [];
}
$store[$requestId] = [
    'message_id' => $messageId,
    'created_at' => time(),
    'file' => $filename,
    'mime' => $mime,
];
file_put_contents($storePath, json_encode($store, JSON_PRETTY_PRINT));

echo json_encode([
    'ok' => true,
    'request_id' => $requestId,
    'telegram_message_id' => $messageId,
]);

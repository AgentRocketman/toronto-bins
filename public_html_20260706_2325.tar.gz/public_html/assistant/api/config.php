<?php
// CurbIn Voice Assistant — PWA backend config
// Fill in TELEGRAM_BOT_TOKEN after creating a dedicated bot via @BotFather.

return [
    // Telegram Bot API token for the assistant bot
    'telegram_bot_token' => '8991461374:AAGfPscA15vMZ4L3BmkmGta-hG8YhpZV60U',

    // Only accept messages / replies from this Telegram user ID
    'allowed_chat_id' => '8714809782',

    // Simple auth token the PWA must send in the X-Auth-Token header
    'api_auth_token' => 'curbin-assistant-dev-2026',

    // Where uploaded audio files are stored temporarily
    'upload_dir' => __DIR__ . '/../uploads/',

    // JSON file used to track pending requests: request_id -> message_id
    'request_store' => __DIR__ . '/../uploads/requests.json',

    // Telegram Bot API base URL
    'telegram_api_base' => 'https://api.telegram.org/bot',

    // OpenClaw local Telegram webhook listener
    'openclaw_webhook_url' => 'http://127.0.0.1:18790/telegram-webhook',
];

<?php
require_once __DIR__ . '/config.php';
$config = require __DIR__ . '/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function error($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

$authHeader = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
if ($authHeader !== $config['api_auth_token']) {
    error('Unauthorized', 401);
}

if ($config['telegram_bot_token'] === '__SET_ME__') {
    error('Telegram bot token not configured', 500);
}

$requestId = $_GET['request_id'] ?? '';
if (!$requestId || !preg_match('/^[a-f0-9]{16}$/', $requestId)) {
    error('Invalid request_id');
}

$storePath = $config['request_store'];
$store = [];
if (file_exists($storePath)) {
    $store = json_decode(file_get_contents($storePath), true) ?: [];
}

if (!isset($store[$requestId])) {
    error('Request not found', 404);
}

$messageId = $store[$requestId]['message_id'];

$updatesPath = $config['upload_dir'] . '/updates.jsonl';
$reply = null;

if (file_exists($updatesPath)) {
    $lines = file($updatesPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $entry = json_decode($line, true);
        if (!$entry || !isset($entry['update'])) continue;

        $update = $entry['update'];
        $msg = $update['message'] ?? $update['channel_post'] ?? null;
        if (!$msg) continue;

        // Only consider messages from the allowed chat ID
        $fromId = $msg['from']['id'] ?? $msg['chat']['id'] ?? null;
        if ((string) $fromId !== (string) $config['allowed_chat_id']) continue;

        $replyTo = $msg['reply_to_message']['message_id'] ?? null;
        if ((string) $replyTo !== (string) $messageId) continue;

        $reply = [];
        if (isset($msg['text'])) {
            $reply['type'] = 'text';
            $reply['text'] = $msg['text'];
        } elseif (isset($msg['voice'])) {
            $reply['type'] = 'voice';
            $reply['file_id'] = $msg['voice']['file_id'];
            $reply['duration'] = $msg['voice']['duration'] ?? null;
            $reply['mime_type'] = $msg['voice']['mime_type'] ?? 'audio/ogg';
        } elseif (isset($msg['audio'])) {
            $reply['type'] = 'audio';
            $reply['file_id'] = $msg['audio']['file_id'];
            $reply['duration'] = $msg['audio']['duration'] ?? null;
        }

        break;
    }
}

if ($reply) {
    echo json_encode([
        'ok' => true,
        'status' => 'replied',
        'reply' => $reply,
    ]);
} else {
    echo json_encode([
        'ok' => true,
        'status' => 'waiting',
    ]);
}
